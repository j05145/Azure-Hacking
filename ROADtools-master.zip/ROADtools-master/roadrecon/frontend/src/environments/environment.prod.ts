export const environment = {
  production: true,
  apibase: '/api/'
};
